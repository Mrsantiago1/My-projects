alert('hi :D')
var month ;
var date ;
var submit;

document.getElementById("submit").onclick= compare;

function compare(){
  //input their birth informtion
  var month = document.getElementById("month").value;
  var date = document.getElementById("date").value

  if (month == "january" && date<=21){
    document.getElementById('sign').innerHTML="capricorn"
    document.getElementById('horoscope').innerHTML="Capricorn people are the type that are goal oriented and driven to succeed despite all odds. They will work long and hard hours toward a purposeful goal. Self-disciplined and successful, it is no wonder that some of the world’s greatest scientists, leaders, and teachers have been Capricorn.";
  }
  else if (month == "january" && date>=21){
    document.getElementById('sign').innerHTML="aquarius"
    document.getElementById('horoscope').innerHTML="This sign often find themselves in occupations where they are helping on some humanitarian level. They are interested and have a deep concern for the welfare of others. They never know a stranger and are generally loved by all around them. Aquarians never meet a stranger and often will go out of their way to meet with people that they’ve not heard from for years."
  }
  else if (month=="february" && date<=18){
    document.getElementById('sign').innerHTML="aquarius"
    document.getElementById('horoscope').innerHTML="This sign often find themselves in occupations where they are helping on some humanitarian level. They are interested and have a deep concern for the welfare of others. They never know a stranger and are generally loved by all around them. Aquarians never meet a stranger and often will go out of their way to meet with people that they’ve not heard from for years. Connection is at the core of this sign.";
  }
  else if (month== "february" && date>=18){
    document.getElementById('sign').innerHTML="pisces"
    document.getElementById('horoscope').innerHTML="Pisces tend to be daydreamers, often dreaming up brilliant ideas and plans which they are unable to facilitate themselves. They have a happy and vibrant inner life that few get to share or see. They are deeply caring about others and don’t like to see people become unhappy.";
  }
  else if (month== "march" &&  date<=20){
    document.getElementById('sign').innerHTML="pisces"
    document.getElementById('horoscope').innerHTML="Pisces tend to be daydreamers, often dreaming up brilliant ideas and plans which they are unable to facilitate themselves. They have a happy and vibrant inner life that few get to share or see. They are deeply caring about others and don’t like to see people become unhappy.";
  }
  else if (month== "march" && date>=21){
    document.getElementById('sign').innerHTML="aries"
    document.getElementById('horoscope').innerHTML="Aries is full of life and possesses high energy, which makes this sign always looking for a challenge. The typical Aries person is full of vitality, curiosity, and has a heightened sense of justice. They often excel at anything where a bit of competition is involved, whether this is of a cognitive nature or physical. The challenge is the thing. If there is a chance to win, to best someone, to show off abilities, Aries is in it to win it. The Aries person feels most alive when they are in control and leading others. They are often impatient and abrupt with those whom they feel are not their equals and are in a leadership position. Most Aries do not like being told what to do if the person in charge is less talented than they.";
  }
  else if (month=="april" && date<=19){
    document.getElementById('sign').innerHTML="aries"
    document.getElementById('horoscope').innerHTML="Aries is full of life and possesses high energy, which makes this sign always looking for a challenge. The typical Aries person is full of vitality, curiosity, and has a heightened sense of justice. They often excel at anything where a bit of competition is involved, whether this is of a cognitive nature or physical. The challenge is the thing. If there is a chance to win, to best someone, to show off abilities, Aries is in it to win it. The Aries person feels most alive when they are in control and leading others. They are often impatient and abrupt with those whom they feel are not their equals and are in a leadership position. Most Aries do not like being told what to do if the person in charge is less talented than they.";
  }
  else if (month=="april" && date>=20){
    document.getElementById('sign').innerHTML="taurus"
    document.getElementById('horoscope').innerHTML="This sign is often very deliberate in their actions, relaxed, and enjoys all of the sensual pleasures that abound in this dimension. Food, drink, sex, luxury, are all sought after by the typical taruean. Because this sign loves luxury they are willing to work hard to obtain it. They are slow to anger, but once disturbed it can be volatile. Taurus signs look for stability in their lives and in their partners and co-workers. Taurus people are not in a hurry, typically, and it can take them many years to decide what it is that they would like to do for a living, or where they’d like to go on vacation. Many of this sign prefer to live in the country as they are drawn to the earth and the natural world.";
  }
  else if (month =="may" && date<=19){
    document.getElementById('sign').innerHTML="taurus"
    document.getElementById('horoscope').innerHTML="This sign is often very deliberate in their actions, relaxed, and enjoys all of the sensual pleasures that abound in this dimension. Food, drink, sex, luxury, are all sought after by the typical taruean. Because this sign loves luxury they are willing to work hard to obtain it. They are slow to anger, but once disturbed it can be volatile. Taurus signs look for stability in their lives and in their partners and co-workers. Taurus people are not in a hurry, typically, and it can take them many years to decide what it is that they would like to do for a living, or where they’d like to go on vacation. Many of this sign prefer to live in the country as they are drawn to the earth and the natural world.";
  }
  else if (month=="may" && date>=20){
    document.getElementById('sign').innerHTML="gemini"
    document.getElementById('horoscope').innerHTML="Communication is a key element for this sign, so many of this sign go into occupations that include some communication in some large capacity. Curiosity is a key characteristic of this sign, and they are people persons. Gemini are great at parties because they can find almost anything to talk about with anyone. Gemini are adventurous by nature and so engage in traveling as often as they can as it affords them the opportunity to meet new people, experience new ideas, and to learn new concepts.";
  }
  else if (month=="june" && date<=20){
    document.getElementById('sign').innerHTML="gemini"
    document.getElementById('horoscope').innerHTML="Communication is a key element for this sign, so many of this sign go into occupations that include some communication in some large capacity. Curiosity is a key characteristic of this sign, and they are people persons. Gemini are great at parties because they can find almost anything to talk about with anyone. Gemini are adventurous by nature and so engage in traveling as often as they can as it affords them the opportunity to meet new people, experience new ideas, and to learn new concepts.";
  }
  else if (month=="june" && date>=21){
    document.getElementById('sign').innerHTML="cancer"
    document.getElementById('horoscope').innerHTML="Cancer have an offbeat sense of humor, often finding something humorous that others don’t. They are extremely good listeners and have a heart for the problems of others. In fact, many gravitate toward this sign because they intuitively know that a Cancer will understand. When a Cancer becomes your friend you can be sure that they are truly your friend and will not consider using someone to their own benefit. Cancer tend to be dependable and reliable. They will tell you anything you want to know about them without blinking an eye as they are drawn to honesty in others as well as themselves.";
  }
  else if (month=="july" && date<=22) {
    document.getElementById('sign').innerHTML="cancer"
    document.getElementById('horoscope').innerHTML="Cancer have an offbeat sense of humor, often finding something humorous that others don’t. They are extremely good listeners and have a heart for the problems of others. In fact, many gravitate toward this sign because they intuitively know that a Cancer will understand. When a Cancer becomes your friend you can be sure that they are truly your friend and will not consider using someone to their own benefit. Cancer tend to be dependable and reliable. They will tell you anything you want to know about them without blinking an eye as they are drawn to honesty in others as well as themselves.";
  }
  else if (month=="july" && date>=23) {
    document.getElementById('sign').innerHTML="leo"
    document.getElementById('horoscope').innerHTML="Leo tend to be honest and decent people, opting to do the right thing regardless of the situation. They love organization so that they can find their ‘things’. Leos love material goods and luxury and want those that they love to experience this wealth as well. Leo are generally accepting of everyone initially and make decent, lasting relationships.";
  }
  else if (month=="august" && date<=20) {
    document.getElementById('sign').innerHTML="leo"
    document.getElementById('horoscope').innerHTML="Leo tend to be honest and decent people, opting to do the right thing regardless of the situation. They love organization so that they can find their ‘things’. Leos love material goods and luxury and want those that they love to experience this wealth as well. Leo are generally accepting of everyone initially and make decent, lasting relationships.";
  }
  else if (month=="august"&& date>=21) {
    document.getElementById('sign').innerHTML="virgo"
    document.getElementById('horoscope').innerHTML="Virgo people are mild mannered on the surface, but underneath there is a flurry of activity. Their minds are never quiet; always thinking, calculating, assessing. They loves making something out of nothing, nurturing and growing small things. They tend to be extremely detail oriented and particularly like producing something that is not only useful, but beautiful and skillful.";
  }
  else if (month=="september" && date<=21) {
    document.getElementById('sign').innerHTML="virgo"
    document.getElementById('horoscope').innerHTML="Virgo people are mild mannered on the surface, but underneath there is a flurry of activity. Their minds are never quiet; always thinking, calculating, assessing. They loves making something out of nothing, nurturing and growing small things. They tend to be extremely detail oriented and particularly like producing something that is not only useful, but beautiful and skillful.";
  }
  else if (month=="september" && date>=22) {
    document.getElementById('sign').innerHTML="libra"
    document.getElementById('horoscope').innerHTML="Libra people need to keep a balance between work lives and recreational lives and an equal balance in their emotional and spiritual/physical lives. Because of this need Libra signs can sometimes seem wishy-washy when they are asked to make a decision. This is because they must ‘weigh’ all of their options. However, rest assured, that when a Libra makes up their mind the decision is likely to be the best win/win for all involved; benefiting the most people. This sign does not like to see people unhappy.";
  }
  else if (month=="october" && date<=21) {
    document.getElementById('sign').innerHTML="libra"
    document.getElementById('horoscope').innerHTML="Libra people need to keep a balance between work lives and recreational lives and an equal balance in their emotional and spiritual/physical lives. Because of this need Libra signs can sometimes seem wishy-washy when they are asked to make a decision. This is because they must ‘weigh’ all of their options. However, rest assured, that when a Libra makes up their mind the decision is likely to be the best win/win for all involved; benefiting the most people. This sign does not like to see people unhappy.";
  }
  else if (month=="october" && date>=22) {
    document.getElementById('sign').innerHTML="scorpio"
    document.getElementById('horoscope').innerHTML="This creature was chosen because it typifies many of the characteristics of this sign. The scorpio person is not necessarily aggressive on its own, unless provoked and in general would rather be contemplative. They crave alone time and often become extremely annoyed when they don’t get it. Scorpio people are great secret keepers and feel each emotion more intensely than other signs. Perhaps because of this they are able to be quite discerning when assisting people with their problems. They are able to cut to the bottom line and show others the best and the worst in their lives.";
  }
  else if (month=="november" && date<=20) {
    document.getElementById('sign').innerHTML="scorpio"
    document.getElementById('horoscope').innerHTML="This creature was chosen because it typifies many of the characteristics of this sign. The scorpio person is not necessarily aggressive on its own, unless provoked and in general would rather be contemplative. They crave alone time and often become extremely annoyed when they don’t get it. Scorpio people are great secret keepers and feel each emotion more intensely than other signs. Perhaps because of this they are able to be quite discerning when assisting people with their problems. They are able to cut to the bottom line and show others the best and the worst in their lives.";
  }
  else if (month=="november" && date>=21) {
    document.getElementById('sign').innerHTML="sagittarius"
    document.getElementById('horoscope').innerHTML="Sagittarians crave the freedom of the open road, both metaphorically and physically. They are most unhappy when they are tied to a normal routine and can become restless in situations where there is not enough variety involved. Because they travel so much and are eager to experience new things, those of this sign are fun to be around and often have large numbers of friends. They question everything and think that everyone should do the same.";
  }
  else if (month=="december" && date<=20) {
    document.getElementById('sign').innerHTML="sagittarius"
    document.getElementById('horoscope').innerHTML="Sagittarians crave the freedom of the open road, both metaphorically and physically. They are most unhappy when they are tied to a normal routine and can become restless in situations where there is not enough variety involved. Because they travel so much and are eager to experience new things, those of this sign are fun to be around and often have large numbers of friends. They question everything and think that everyone should do the same.";
  }
  else if (month=="december" && date>=21) {
    document.getElementById('sign').innerHTML="capricorn"
    document.getElementById('horoscope').innerHTML="Capricorn people are the type that are goal oriented and driven to succeed despite all odds. They will work long and hard hours toward a purposeful goal. Self-disciplined and successful, it is no wonder that some of the world’s greatest scientists, leaders, and teachers have been Capricorn.";
  }
}
//display horoscope

alert("click on animals");
/*Ths is a game where the user expects the animal images on the screen to move
and make a noise when clicked
*/
x = 0;
y = 0;
var cow = document.getElementById("cow");
var horse = document.getElementById("horse");
var chicken = document.getElementById("chicken");
var pig = document.getElementById("pig");
var cowSound = document.getElementById("cowSound");
var horseSound = document.getElementById("horseSound");
var chickenSound = document.getElementById("chickenSound");
var pigSound = document.getElementById("pigSound");
//var moo = document.getElementsByElement("moo")
 //the animal event listeners that allow them to move when clicked
  pig.onclick=function movement(){
  var x = Math.floor(Math.random()*500);
  var y = Math.floor(Math.random()*500);
  pig.style.top = x + 'px';
  pig.style.left = y + 'px';
  pigSound.play();
}
  cow.onclick=function movement(){
  var x = Math.floor(Math.random()*500);
  var y = Math.floor(Math.random()*500);
  cow.style.top = x + 'px';
  cow.style.left = y + 'px';
  cowSound.play();
  //cow.onclick = moo.play();
}
  chicken.onclick=function movement(){
  var x = Math.floor(Math.random()*500);
  var y = Math.floor(Math.random()*500);
  chicken.style.top = x + 'px';
  chicken.style.left = y + 'px';
  chickenSound.play();
}
  horse.onclick=function movement(){
  var x = Math.floor(Math.random()*500);
  var y = Math.floor(Math.random()*500);
  horse.style.top = x + 'px';
  horse.style.left = y + 'px';
  horseSound.play();
}
